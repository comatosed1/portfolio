/* Developer: Sean Fitzpatrick
 * Date: 8/4/2025
 * Purpose: Test for ContactService class for CS 320 Module 3 Milestone Assignment
 * Updated as part of M6 Project 1 Submission
 * */

package tests;

import org.junit.jupiter.api.Test;
import source.ContactService;
import source.Contact;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
	
	@Test
	// Test case for adding and deleting contact
	public void testAddDeleteContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("2814", "Jessica", "Cruz", "0987654321", "2014 Johns Sciver Rd");
		service.addContact(contact);
		assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
		service.deleteContact("2814");
		assertThrows(IllegalArgumentException.class, () -> service.deleteContact("2814"));
		
		
		
	}
	
	@Test
	// Test case for updating information fields
	public void testUpdates() {
		ContactService service = new ContactService();
		Contact contact = new Contact("0123", "Wallace", "Wests", "2225558796", "1959 Infantino Dr");
		service.addContact(contact);
		service.updateFirstName("0123", "Wally");
		service.updateLastName("0123", "West");
		service.updatePhone("0123", "5556781234");
		service.updateAddress("0123",  "110 Broome Avenue");
		assertEquals("Wally", contact.getFirstName());
		assertEquals("West", contact.getLastName());
		assertEquals("5556781234", contact.getPhone());
		assertEquals("110 Broome Avenue", contact.getAddress());
		
	}
	
	@Test
	// Test case for invalid ID
	public void testInvalidID() {
		ContactService service = new ContactService();
		assertThrows(IllegalArgumentException.class, () -> service.getContact(null));
	}
	
}
