/* Developer: Sean Fitzpatrick
 * Date: 8/4/2025
 * Purpose: Tests for Contact class for CS 320 Module 3 Milestone Assignment
 * Updated as part of M6 Project 1 Submission
 * */
package tests;

import org.junit.jupiter.api.Test;
import source.Contact;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
	@Test
	// Test case to check if Contact Creation is functioning
	public void testContactCreation() {
		Contact contact = new Contact("001", "Barry", "Allen", "1238675309", "1956 Showcase Dr");
		assertEquals("001", contact.getContactId());
		assertEquals("Barry", contact.getFirstName());
		assertEquals("Allen", contact.getLastName());
		assertEquals("1238675309", contact.getPhone());
		assertEquals("1956 Showcase Dr", contact.getAddress());
	
		
	}
	
	@Test
	public void testValidEdgeCases() {
	    // All fields are at the maximum allowed length
	    Contact contact = new Contact("1234567890", "Firstname1", "Lastname12", "1234567890", "123456789012345678901234567890");
	    assertEquals("1234567890", contact.getContactId());
	    assertEquals("Firstname1", contact.getFirstName());
	    assertEquals("Lastname12", contact.getLastName());
	    assertEquals("1234567890", contact.getPhone());
	    assertEquals("123456789012345678901234567890", contact.getAddress());
	}
	
	@Test
	public void testSettersWithValidEdgeCases() {
		
		// Test case for max allowed values
	    Contact contact = new Contact("id", "fn", "ln", "1234567890", "addr");

	    contact.setFirstName("ABCDEFGHIJ"); // 10 chars
	    contact.setLastName("KLMNOPQRST");  // 10 chars
	    contact.setPhone("0987654321");
	    contact.setAddress("123456789012345678901234567890"); // 30 chars

	    assertEquals("ABCDEFGHIJ", contact.getFirstName());
	    assertEquals("KLMNOPQRST", contact.getLastName());
	    assertEquals("0987654321", contact.getPhone());
	    assertEquals("123456789012345678901234567890", contact.getAddress());
	}
	
	@Test
	public void testMinimumLengthInputs() {
	    Contact contact = new Contact("1", "A", "B", "1234567890", "1");
	    assertEquals("1", contact.getContactId());
	    assertEquals("A", contact.getFirstName());
	    assertEquals("B", contact.getLastName());
	    assertEquals("1234567890", contact.getPhone());
	    assertEquals("1", contact.getAddress());
	}
	
	@Test
	// Test case to test invalid ID
	public void testInvalidID() {		
		assertThrows(IllegalArgumentException.class, () -> new Contact("01234567891234", "Bart", "Allen", "1234567890", "1954 Showcase Dr"));
		assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Bart", "Allen", "1234567890", "1954 Showcase Dr"));
	}
	
	@Test
	// Test case for invalid first name
	public void testInvalidFirstName() {
		assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Alan-Jordan", "Stewart", "1234567890", "123 That Place Avenue"));
		assertThrows(IllegalArgumentException.class, () -> new Contact("123", null, "Stewart", "1234567890", "123 That Place Avenue"));
	}

	
	@Test
	// Test case for invalid last name
	public void testInvalidLastName() {
		assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Alan", "Stewart-Gardner", "1234567890", "132 That other Place Drive"));
		assertThrows(IllegalArgumentException.class, () -> new Contact("124", "Alan", null, "1234567890", "132 That other Place Drive"));
	}

	@Test
	// Test case for invalid address entry
	public void testInvalidAddress() {
		assertThrows(IllegalArgumentException.class, () -> new Contact("1233", "Alan", "Scott", "1234567890", null));
		assertThrows(IllegalArgumentException.class, () -> new Contact("1234", "Jenny-Lynn", "Hayden", "1234567890", "123456789 Green Skin Drive, Gotham City, NJ"));
	}
	
	@Test
	// Test case to check if Phone number meets requirements
	public void testInvalidPhone() {
		
		// First assertion checks if the Phone number is too short
		assertThrows(IllegalArgumentException.class, () -> new Contact("002", "Hal", "Jordan", "123", "59 Gil Broome Avenue"));
		// Second assertion checks if the phone number is too long
		assertThrows(IllegalArgumentException.class, () -> new Contact("002", "Hal", "Jordan", "12345678901", "59 Gil Broome Avenue"));
		assertThrows(IllegalArgumentException.class, () -> new Contact("002", "Hal", "Jordan", null, "59 Gil Broome Avenue"));
	}
	
	@Test
	public void testInvalidPhoneWithNonDigits() {
		
		// Test case for entering phone number with characters
	    assertThrows(IllegalArgumentException.class, () -> new Contact("005", "Test", "User", "12345abcd9", "123 Road St"));
	    Contact contact = new Contact("006", "Test", "User", "1234567890", "456 Road St");
	    assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12a4567890"));
	}
	
	@Test
	// Test case to test Setter code
	public void testSetters() {
		Contact contact = new Contact("003", "Jon", "Stewarts", "1234567890", "1971 O'Neil Avenue");
		contact.setFirstName("John");
		contact.setLastName("Stewart");
		contact.setPhone("0001234567");
		contact.setAddress("1971 Adams Avenue");
		assertEquals("John", contact.getFirstName());
		assertEquals("Stewart", contact.getLastName());
		assertEquals("0001234567", contact.getPhone());
		assertEquals("1971 Adams Avenue", contact.getAddress());
	}	
	
	@Test
	// Test case to test Setter code with NULL values
	public void testSettersNull() {
		Contact contact = new Contact("123", "Alan", "Scott", "1234567890", "123 Parkway West");
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
		
	}
	
	@Test
	public void testSettersWithSameValues() {
		
		// Testing setters with same values
	    Contact contact = new Contact("007", "Test", "Same", "1112223333", "Same Address");
	    contact.setFirstName("Test");
	    contact.setLastName("Same");
	    contact.setPhone("1112223333");
	    contact.setAddress("Same Address");

	    assertEquals("Test", contact.getFirstName());
	    assertEquals("Same", contact.getLastName());
	    assertEquals("1112223333", contact.getPhone());
	    assertEquals("Same Address", contact.getAddress());
	}
	
	
}
