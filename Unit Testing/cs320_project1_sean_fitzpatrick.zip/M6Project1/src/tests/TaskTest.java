/* Developer: Sean Fitzpatrick
 * Date: 08/07/2025
 * Purpose: M6 Project 1, TaskTest.java JUnit Testing class
 */

package tests;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import source.Task;


public class TaskTest {
	
	@Test
	// Test to check Task creation
	public void testTaskCreation() {
		Task task = new Task("001", "Task Alpha", "Primary Task Mumbo Jumbo.");
		assertEquals("001", task.getTaskId());
		assertEquals("Task Alpha", task.getTaskName());
		assertEquals("Primary Task Mumbo Jumbo.", task.getTaskDescription());
	}
	
	@Test
	// Testing Null values
	public void testTaskCreationNull() {
		assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task Omega", "Task Omega Description"));
		assertThrows(IllegalArgumentException.class, () -> new Task("001", null, null));
	}
	
	@Test
	// Second Test to check Task Creation
	public void testTaskCreationTwo() {
		Task task = new Task("002", "Task Beta", "Secondary Task Creation Test");
		assertEquals("002", task.getTaskId());
		assertEquals("Task Beta", task.getTaskName());
		assertEquals("Secondary Task Creation Test", task.getTaskDescription());
	}
	
	@Test
	// Test to check if taskName is too long
	public void testTaskName() {
		
		assertThrows(IllegalArgumentException.class, () -> new Task("002", "TaskBetaABCDEFGHIJKLMN", "Secondary Task Mumbo Jumbo."));

	}

	
	@Test
	// Test to check if taskDesc is too long
	public void testTaskDescription() {
		assertThrows(IllegalArgumentException.class, () -> new Task("003", "Task Gamma", "Tertiary Task Mumbo Jumbo Tertiary Task Mumbo Jumbo Tertiary Task Mumbo Jumbo"));
	}
	
	@Test
	// Test Setters Test One
	public void testSetters() {
		Task task = new Task("004", "TaskDlta", "Task description stuff");
		task.setTaskName("Task Delta");
		task.setTaskDescription("Delta Description");
		assertEquals("Task Delta", task.getTaskName());
		assertEquals("Delta Description", task.getTaskDescription());
	}
	
	@Test
	// Test Setters Test Two
	public void testSettersTwo() {
		Task task = new Task("005", "TaskCappa", "More Task stuff");
		task.setTaskName("Task Kappa");
		task.setTaskDescription("Fourth Task Description");
		assertEquals("Task Kappa", task.getTaskName());
		assertEquals("Fourth Task Description", task.getTaskDescription());
	}
	
	@Test
	// Test set too long task name
	public void testSettersName() {
		Task task = new Task("012", "Task Testing", "Task Description");
		assertThrows(IllegalArgumentException.class, () -> task.setTaskName(null));
		assertThrows(IllegalArgumentException.class, () -> task.setTaskName("THIS IS WAY TOO LONG TO USE AS A TASK NAME"));
	}
	
	@Test
	// Test sets for too long description
	public void testSettersDescription() {
		Task task = new Task("014", "Task Testing 2", "Task Description 2");
		assertThrows(IllegalArgumentException.class, () -> 	task.setTaskDescription(null));
		assertThrows(IllegalArgumentException.class, () -> 	task.setTaskDescription("THIS IS WAY TOO LONG TO USE AS A TASK DESCRIPTION. IT NEEDS TO BE SHORTER. BLAH BLAH BLAH"));	
	}
	
}
