/* Developer: Sean Fitzpatrick
 * Date: 08/07/2024
 * Description: M6 Project 1, TaskserviceTest class
 */
package tests;

import org.junit.jupiter.api.Test;
import source.Task;
import source.TaskService;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
	
	@Test
	
	// Test case for adding TaskID
	public void testAddTask() {
		TaskService service = new TaskService();
		Task task = new Task("001", "Task Alpha", "Task Alpha Description");
		service.addTask(task);
		assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
	}

	@Test
	// Test case for deleting tasks
	public void testDeleteTask() {
		TaskService service = new TaskService();
		Task task = new Task("002", "Task Beta", "Task to be deleted");
		service.addTask(task); // add task before it can be deleted
		service.deleteTask(task.getTaskId());
		assertThrows(IllegalArgumentException.class, () -> service.deleteTask(task.getTaskId()));
		
	}
	
	@Test
	// Test case for updating taskName
	public void testUpdateTaskName() {
		TaskService service = new TaskService();
		Task task = new Task("003", "TBD", "Task Open");
		service.addTask(task);
		service.updateTaskName("003", "Task Gamma");
			
	}
	
	@Test
	// Another test case for updating taskName
	public void testUpdateTaskNameAgain() {
		TaskService service = new TaskService();
		Task task = new Task("004", "TBD", "Task Open");
		service.addTask(task);
		service.updateTaskName("004", "Task Delta");
	}
	
	@Test
	// Test case for updating taskDesc
	public void testUpdateTaskDescription() {
		TaskService service = new TaskService();
		Task task = new Task("004", "Task Delta", "TBD Task Description");
		service.addTask(task);
		service.updateTaskDescription("004", "Eliminate all bugs in code");
		
	}
	
	@Test
	// Test case for updating taskDesc
	public void testUpdateTaskDescriptionAgain() {
		TaskService service = new TaskService();
		Task task = new Task("012", "Task Force X", "TBD Task Description");
		service.addTask(task);
		service.updateTaskDescription("012", "Eliminate all bugs in code");
	
	}

	
	@Test
	// Test case for updating taskName with invalid taskID
	public void testUpdateNameInvalidId() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.updateTaskName(null, "Any Name"));
	}
	
	@Test
	// Test case for updating taskDesc with invalid TaskID
	public void testUpdateDescriptionInvalidId() {
		TaskService service = new TaskService();
		assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription(null, "Any description will do"));
	}
}
