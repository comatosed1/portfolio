/* Developer: Sean Fitzpatrick
 * Date: 8/4/2025
 * Purpose: ContactService class for CS 320 Module 3 Milestone Assignment
 * Updated as part of M6 Project 1 Submission
 * */

package source;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	// Storing key-value pairs in HashMap (Contact ID, Contact)
	private final Map<String, Contact> contacts = new HashMap<>();
	
	// Method to add a contact to HashMap
	public void addContact(Contact contact) {
		// Checks if contact already exists
		if(contacts.containsKey(contact.getContactId())) {
			throw new IllegalArgumentException("Contact ID already exists");
		}
		contacts.put(contact.getContactId(), contact);
	}
	
	// Method to delete contact from HashMap
	public void deleteContact(String contactId) {
		// Checks to see if the contact exists so it can be deleted
		if (!contacts.containsKey(contactId)) {
			throw new IllegalArgumentException("Contact not found");
		}
		
		contacts.remove(contactId);
	}
	
	// Method to update contact first name in HashMap
	public void updateFirstName(String contactId, String firstName) {
		Contact contact = getContact(contactId);
		contact.setFirstName(firstName);
	}
	
	// Method to update last name in HashMap
	public void updateLastName(String contactId, String lastName) {
		Contact contact = getContact(contactId);
		contact.setLastName(lastName);
	}
	
	// Method to update phone number
	public void updatePhone(String contactId, String phone) {
		Contact contact = getContact(contactId);
		contact.setPhone(phone);
	}
	
	// Method to update address
	public void updateAddress(String contactId, String address) {
		Contact contact = getContact(contactId);
		contact.setAddress(address);
	}
	
	// Method to get specific contact information from Contact ID
	public Contact getContact(String contactId) {
		Contact contact = contacts.get(contactId);
		if(contact == null) {
			throw new IllegalArgumentException("Contact not found");
			
		}
		return contact;
	}
}
