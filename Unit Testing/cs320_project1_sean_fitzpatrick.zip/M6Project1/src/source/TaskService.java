/* Developer: Sean Fitzpatrick
 * Date: 08/07/2025
 * Purpose: TaskService class for CS 320 Module 6 Project 1
 * */
package source;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

		// Store key value pairs in HashMap (TaskId, Task)
		private final Map<String, Task> tasks = new HashMap<>();
		
		public void addTask(Task task) {
			// searches key value pairs for already existing taskId
			if(tasks.containsKey(task.getTaskId())) {
				throw new IllegalArgumentException("Task ID already exists");
			}
			tasks.put(task.getTaskId(), task);
		}
		
		// method to delete task from the HashMap
		public void deleteTask(String taskId) {
			// searches for the taskId before attempting to delete
			if(!tasks.containsKey(taskId)) {
				throw new IllegalArgumentException("Task not found");
			}
			tasks.remove(taskId);
		}
		
		// method to update taskName
		public void updateTaskName(String taskId, String taskName) {
			Task task = getTask(taskId);
			task.setTaskName(taskName);
			
		}
		
		// method to update taskDesc
		public void updateTaskDescription(String taskId, String taskDesc) {
			Task task = getTask(taskId);
			task.setTaskDescription(taskDesc);
		}
		
		public Task getTask(String taskId) {
			Task task = tasks.get(taskId);
			if(task == null) {
				throw new IllegalArgumentException("Task not found");
			}
			return task;
		}
}
