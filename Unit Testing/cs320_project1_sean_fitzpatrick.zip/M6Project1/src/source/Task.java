/* Developer: Sean Fitzpatrick
 * Date: 08/07/2025
 * Purpose: M6 Project 1, Task.java class
 */
package source;


public class Task {
	
	private final String taskId; // taskId cannot be updated
	private String taskName;
	private String taskDesc;

	
	public Task(String taskId, String taskName, String taskDesc) {
		// checks and determines that the variables meet requirements
		if(taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid task ID");
		}
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task name");
			
		}
		if(taskDesc == null || taskDesc.length()> 50) {
			throw new IllegalArgumentException("Invalid task description");
		}
		
		this.taskId = taskId;
		this.taskName = taskName;
		this.taskDesc = taskDesc;
	}
	
	// getter for taskID
	public String getTaskId() {
		return taskId;
	}
	
	// getter for taskName
	public String getTaskName() {
		return taskName;
	}
	
	// getter for taskDesc
	public String getTaskDescription() {
		return taskDesc;
	}
	
	// setter for taskName
	public void setTaskName(String taskName) {
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task name");
		}
		
		this.taskName = taskName;
		
	}
	
	// setter for taskDesc
	public void setTaskDescription(String taskDesc) {
		if(taskDesc == null || taskDesc.length() > 50) {
			throw new IllegalArgumentException("Invalid task description");
		}
		
		this.taskDesc = taskDesc;
	}
	
}
