/* Developer: Sean Fitzpatrick
 * Date: 8/4/2025
 * Purpose: Contact class for CS 320 Module 3 Milestone Assignment
 * Updated as part of M6 Project 1 submission
 * */
package source;

public class Contact {
	private final String contactId;
	public String firstName;
	public String lastName;
	public String phone;
	public String address;
	
	public Contact(String contactId, String firstName, String lastName, String phone, String address) {
		
		// Checks to make sure that the requested information meets the desired requirements
		if(contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Invalid contact ID");
		}
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		if(phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
		
	}
	
	// Getter for contactID
	public String getContactId() {
		return contactId;
	}
	
	// Getter for first name
	public String getFirstName() {
		return firstName;
	}
	
	// Setter for first name
	public void setFirstName(String firstName) {
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name");
			
		}
		this.firstName = firstName;
	}
	
	// Getter for last name
	public String getLastName() {
		return lastName;
	}
	
	// Setter for last name
	public void setLastName(String lastName) {
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		this.lastName = lastName;
	}
	
	// Getter for phone number
	public String getPhone() {
		return phone;
	}
	
	// Setter for phone number
	public void setPhone(String phone) {
		if (phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
			throw new IllegalArgumentException("Invalid phone number");
		}
		this.phone = phone;
	}
	
	// Getter for address
	public String getAddress() {
		return address;
	}
	
	// Setter for address
	public void setAddress(String address) {
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.address = address;
	}
}
