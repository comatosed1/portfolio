/* Developer: Sean Fitzpatrick
 * Date: 8/1/2025
 * Purpose: Module 5, AppointmentService class testing class
 */
package tests;

import java.util.Date;
import source.AppointmentService;
import source.Appointment;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

public class AppointmentServiceTest {
	private AppointmentService service;
	private Appointment appointment;
	
	@BeforeEach
	// setup to make code more efficient
	public void setUp() {
		service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 10000);
		appointment = new Appointment("001", futureDate, "Doctor Visit");
	}
	
	@Test
	// Test to add appointment with valid information
	public void addAppointment() {
		service.addAppointment(appointment);
		assertEquals(appointment, service.getAppointment("001"));
	}
	
	@Test
	// Test to add duplicate appointment
	public void addDuplicateAppointment() {
		service.addAppointment(appointment);
		assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment));
	}
	
	@Test
	// Test to delete existent appointment
	public void deleteAppointment() {
		service.addAppointment(appointment);
		service.deleteAppointment("001", appointment);
		assertNull(service.getAppointment("001"));
		
		
	}
	
	@Test
	// Test to delete non-existent appointment
	public void deleteNonExistantAppointment() {
		assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("INVALID", appointment));
	}
	
	
}
