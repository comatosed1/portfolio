/* Developer: Sean Fitzpatrick
 * Date: 8/1/2025
 * Purpose: Module 5 Milestone, Appointment Class Test class using JUnit 5
 */
package tests;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import source.Appointment;

public class AppointmentTest {

		@Test
		// Test for valid appointment creation
		public void testValidAppointmentCreation() {
			Date futureDate = new Date(System.currentTimeMillis() + 10000);
			Appointment appointment = new Appointment("001", futureDate, "Doctor Visit");
			assertEquals("001", appointment.getAppointmentId());
			assertEquals(futureDate, appointment.getAppointmentDate());
			assertEquals("Doctor Visit", appointment.getDescription());
		}
		
		@Test
		// Test for invalid appointment ID
		public void testInvalidAppointmentID() {
			Date futureDate = new Date(System.currentTimeMillis() + 10000);
			assertThrows(IllegalArgumentException.class, () -> new Appointment("012345678915", futureDate, "Valid Description"));
			assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Valid Description"));
		}
		
		@Test
		// Test for invalid date(Past Date and null entry)
		public void testInvalidAppointmentDate() {
			Date pastDate = new Date(System.currentTimeMillis() - 100000); // Creates a date prior to the current date and time
			assertThrows(IllegalArgumentException.class, () -> new Appointment("002", pastDate, "Visit Description"));
			assertThrows(IllegalArgumentException.class, () -> new Appointment("002", null, "Visit Description"));
		}
		
		@Test
		// Test for invalid description (null, too long)
		public void testInvalidDescription() {
			Date futureDate = new Date(System.currentTimeMillis() + 10000);
			assertThrows(IllegalArgumentException.class, () -> new Appointment("003", futureDate, "DescriptionDescriptionDescriptionDescriptionDescriptionDescription"));
			assertThrows(IllegalArgumentException.class, () -> new Appointment("004", futureDate, null));
			
		}
		
		@Test
		// Test for Appointment Setters
		public void testAppointmentSetters() {
			Date futureDate = new Date(System.currentTimeMillis() + 10000);
			Appointment appointment = new Appointment("002", futureDate, "Description to be changed");
			Date updatedDate = new Date(System.currentTimeMillis() + 20000);
			appointment.setAppointmentDate(updatedDate);
			appointment.setDescription("Description is Changed");
			assertEquals("Description is Changed", appointment.getDescription());
			assertEquals(updatedDate, appointment.getAppointmentDate());
			
			
		}
		
		@Test
		// Test to set Invalid parameters
		public void testInvalidSetters() {
			Date futureDate = new Date(System.currentTimeMillis() + 10000);
			Appointment appointment = new Appointment("003", futureDate, "Description");
			Date updatedDate = new Date(System.currentTimeMillis() - 100000);
			assertThrows(IllegalArgumentException.class, () -> appointment.setAppointmentDate(null));
			assertThrows(IllegalArgumentException.class, () -> appointment.setAppointmentDate(updatedDate));
			assertThrows(IllegalArgumentException.class, () -> appointment.setDescription(null));
			assertThrows(IllegalArgumentException.class, () -> appointment.setDescription("DescriptionDescriptionDescriptionDescriptionDescriptionDescription"));
		}
		
}
