/* Developer: Sean Fitzpatrick
 * Date: 8/1/2025
 * Purpose: Module 5 Milestone, AppointmentService class
 */
package source;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	
	// HashMap to hold key pairings, ID/Date/Description & appointment object
	private final Map<String, Appointment> appointments = new HashMap<>();
	
	// method to add appointment
	public void addAppointment(Appointment appointment) {
		if(appointments.containsKey(appointment.getAppointmentId())) {
			throw new IllegalArgumentException("Appointment ID already exists");
		}
		appointments.put(appointment.getAppointmentId(), appointment);
	}
	
	// Method to delete existing appointment
	public void deleteAppointment(String appointmentId, Appointment appointment) {
		if(!appointments.containsKey(appointmentId)) {
			throw new IllegalArgumentException("Appointment ID Not Found");
		}
		appointments.remove(appointmentId, appointment);
	}
	
	// Method to get appointment
	public Appointment getAppointment(String appointmentId) {
		return appointments.get(appointmentId);
	}

}
